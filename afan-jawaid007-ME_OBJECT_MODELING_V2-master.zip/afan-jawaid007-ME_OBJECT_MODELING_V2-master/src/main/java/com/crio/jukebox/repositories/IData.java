package com.crio.jukebox.repositories;

public interface IData {

	void loadData(String dataPath, String delimiter);
    
}