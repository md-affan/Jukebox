package com.crio.jukebox.entities;

public abstract class BaseEntity {
    
    protected String id;

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }
    
}