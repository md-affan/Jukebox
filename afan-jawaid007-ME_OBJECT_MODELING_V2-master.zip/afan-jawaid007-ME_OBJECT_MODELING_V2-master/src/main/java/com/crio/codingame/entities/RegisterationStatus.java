package com.crio.codingame.entities;

public enum RegisterationStatus {
    REGISTERED, NOT_REGISTERED
}
