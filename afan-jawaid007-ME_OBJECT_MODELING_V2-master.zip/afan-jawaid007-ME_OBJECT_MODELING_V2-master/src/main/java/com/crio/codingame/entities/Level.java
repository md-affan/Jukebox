
package com.crio.codingame.entities;

public enum Level {
    LOW,MEDIUM,HIGH
}

